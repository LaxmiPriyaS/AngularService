import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-startworkout',
  templateUrl: './StartWorkout.component.html',
  styles: [] 
})
export class StartWorkoutComponent implements OnInit {
 
  id_currency: string = "";
  my_result: any;
 

  ngOnInit() {
  }

 
}