import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-viewWorkout',
  templateUrl: './ViewWorkout.component.html',
  styles: []
})
export class ViewWorkoutComponent implements OnInit {
  startSearchBox: string = "";

  

  ngOnInit() {
  }
}

 