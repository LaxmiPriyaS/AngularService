"use strict";
var router_1 = require("@angular/router");
var ViewWorkout_component_1 = require("./Workout/ViewWorkout.component");
var CreateWorkout_component_1 = require("./Workout/CreateWorkout.component");
var Category_component_1 = require("./Category/Category.component");
var MAINMENU_ROUTES = [
    { path: '', redirectTo: '/viewWorkout', pathMatch: 'full' },
    { path: 'viewWorkout', component: ViewWorkout_component_1.ViewWorkoutComponent },
    { path: 'createWorkout', component: CreateWorkout_component_1.CreateWorkoutComponent },
    { path: 'category', component: Category_component_1.CategoryComponent }
];
exports.CONST_ROUTING = router_1.RouterModule.forRoot(MAINMENU_ROUTES);
//# sourceMappingURL=app.routing.js.map