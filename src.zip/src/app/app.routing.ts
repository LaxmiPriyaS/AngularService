import { Routes, RouterModule } from '@angular/router';
import { ViewWorkoutComponent } from "./Workout/ViewWorkout.component";
import { CreateWorkoutComponent } from "./Workout/CreateWorkout.component";
import { CategoryComponent } from "./Category/Category.component";

const MAINMENU_ROUTES: Routes = [
    { path: '', redirectTo: '/viewWorkout', pathMatch: 'full' },
    { path: 'viewWorkout', component: ViewWorkoutComponent },
    { path: 'createWorkout', component: CreateWorkoutComponent },
    { path: 'category', component: CategoryComponent }
	
];
export const CONST_ROUTING = RouterModule.forRoot(MAINMENU_ROUTES);